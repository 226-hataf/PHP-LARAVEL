<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;

class Pro extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $alldata = Product::all();
        return $alldata;
    }

    public function store(Request $request)
    {
        $product = Product::create($request->all());
        return response()->json(['status' => true, 'message' => "Stored product", $product]);

    }

    public function destroy($id)
    {
        $product = Product::Find($id);
        $product->delete();
        return response()->json(['status' => true, 'message' => "Deleted product", $product]);
    }

    public function update($id)
    {
        $product=Product::Find($id);
        $product->update();
        return response()->json(['status' => true,'message' => "Updated product", $product]);
    }

    public function show()
    {
        $alldata = Product::all();
        return $alldata;
    }

}
