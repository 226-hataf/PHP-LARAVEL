<?php

namespace App\Http\Controllers;

use App\Models\Category;
use Illuminate\Http\Request;

class Cro extends Controller
{
    public function index()
    {
        $alldata = Category::all();
        return $alldata;

    }

    public function show()
    {
        $alldata = Category::all();
        return $alldata;
    }

    public function update($id)
    {
        $category=Category::Find($id);
        $category->update();
        return response()->json(['status' => true,'message' => "Updated product", $category]);
    }

    public function destroy($id)
    {
        $category = Category::Find($id);
        $category->delete();
        return response()->json(['status' => true, 'message' => "Deleted product", $category]);
    }

    public function store(Request $request)
    {
        $category = Category::create($request->all());
        return response()->json(['status' => true, 'message' => "Stored product", $category]);

    }
}
