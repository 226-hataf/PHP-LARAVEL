<?php

use App\Http\Controllers\Pro;
use App\Http\Controllers\Cro;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;


/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

// Product
/*Route::GET('/show',[Pro::class,'index']);
Route::POST('/store{id}',[Pro::class,'store']);
Route::DELETE('/del/{id}',[Pro::class,'destroy']);
Route::PUT('/up/{id}',[Pro::class,'update']);
*/
Route::apiResource('/product', Pro::class);

//Category
Route::apiResource('/category', Cro::class);










